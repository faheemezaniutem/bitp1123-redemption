#ifndef BINARY_H
#define BINARY_H

class Binary {
private:
    int array[10];

public:
    Binary(int data[]);
    void binarySearch(int target);
};

#endif