#ifndef PROBABILITY_H
#define PROBABILITY_H

class Probability {
private:
    int array[11]; 
    int locationWanted;
    int oldIndex;

public:
    Probability(int data[]);
    bool probabilitySearch(int target);
    void displayCache();
};

#endif