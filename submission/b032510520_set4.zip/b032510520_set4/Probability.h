#include "Probability.h"
#include <iostream>
using namespace std;

Probability::Probability(int data[]) {
    for (int i = 0; i < 10; i++) {
        array[i] = data[i];
    }
    locationWanted = -1;
    oldIndex = -1;
}

bool Probability::probabilitySearch(int target) {
    for (int i = 0; i < 10; i++) {
        if (array[i] == target) {
            oldIndex = i;
            if (i > 0) {
                
                int temp = array[i];
                array[i] = array[i - 1];
                array[i - 1] = temp;
                locationWanted = i - 1;
                cout << "Found " << target << " at index " << locationWanted
                    << " (moved up from index " << oldIndex << ")" << endl;
            }
            else {
                locationWanted = 0;
                cout << "Found " << target << " at index 0 (already at front)" << endl;
            }
            return true;
        }
    }
    cout << "Target not found" << endl;
    return false;
}

void Probability::displayCache() {
    for (int i = 0; i < 10; i++) {
        cout << array[i] << " ";
    }
    cout << endl;
}