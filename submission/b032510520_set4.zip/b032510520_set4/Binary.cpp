#include "Binary.h"
#include <iostream>
using namespace std;

Binary::Binary(int data[]) {
    for (int i = 0; i < 10; i++) {
        array[i] = data[i];
    }
}

void Binary::binarySearch(int target) {
    int begin = 0;
    int end = 9;
    int mid;
    bool found = false;

    while (begin <= end) {
        mid = (begin + end) / 2;
        cout << "mid = " << mid << ", begin = " << begin << ", end = " << end << endl;

        if (array[mid] == target) {
            found = true;
            break;
        }
        else if (array[mid] < target) {
            begin = mid + 1;
        }
        else {
            end = mid - 1;
        }
    }

    if (found) {
        cout << "Found " << target << " at index " << mid << endl;
    }
    else {
        cout << "Target not found" << endl;
    }
}