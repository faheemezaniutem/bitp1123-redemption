#ifndef SENTINEL_H
#define SENTINEL_H

class Sentinel {
private:
    int array[11]; 
public:
    Sentinel();
    bool search(int target, int& index);
    void display();
};

#endif
