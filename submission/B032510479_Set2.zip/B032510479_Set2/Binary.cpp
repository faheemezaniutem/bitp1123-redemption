#include "Binary.h"
#include <iostream>
using namespace std;

Binary::Binary() {
    int temp[10] = { 105, 120, 150, 180, 210, 245, 280, 320, 365, 400 };
    for (int i = 0; i < 10; i++) array[i] = temp[i];
}

bool Binary::search(int target, int& index) {
    int begin = 0, end = 9;
    while (begin <= end) {
        int mid = (begin + end) / 2;
        cout << "mid = " << mid << ", begin = " << begin << ", end = " << end << endl;
        if (array[mid] == target) {
            index = mid;
            return true;
        }
        else if (array[mid] < target) {
            begin = mid + 1;
        }
        else {
            end = mid - 1;
        }
    }
    return false;
}

void Binary::display() {
    cout << "Archive   : ";
    for (int i = 0; i < 10; i++) cout << array[i] << " ";
    cout << endl;
}
