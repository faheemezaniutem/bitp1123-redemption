#include "Sentinel.h"
#include <iostream>
using namespace std;

Sentinel::Sentinel() {
    int temp[10] = { 1001, 2045, 3012, 4078, 5099, 6034, 7056, 8021, 9088, 1076 };
    for (int i = 0; i < 10; i++) array[i] = temp[i];
}

bool Sentinel::search(int target, int& index) {
    array[10] = target; 
    index = 0;
    while (array[index] != target) index++;
    return (index < 10);
}

void Sentinel::display() {
    cout << "Hot-Access: ";
    for (int i = 0; i < 10; i++) cout << array[i] << " ";
    cout << endl;
}
