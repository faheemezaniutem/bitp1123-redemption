#ifndef BINARY_H
#define BINARY_H

class Binary {
private:
    int array[10];
public:
    Binary();
    bool search(int target, int& index);
    void display();
};

#endif

