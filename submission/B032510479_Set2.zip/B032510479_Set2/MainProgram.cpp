#include <iostream>
#include "Sentinel.h"
#include "Binary.h"
using namespace std;

int main() {
    Sentinel hot;
    Binary archive;
    int choice, target, index;

    hot.display();
    archive.display();

    do {
        cout << "\nMenu:\n1. Search Hot-Access Table (Sentinel)\n2. Search Archive Table (Binary)\n3. Exit\n";
        cout << "Choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Insert a target: ";
            cin >> target;
            if (hot.search(target, index))
                cout << "Found " << target << " at index " << index << endl;
            else
                cout << "Target not found" << endl;
            break;

        case 2:
            cout << "Insert a target: ";
            cin >> target;
            if (archive.search(target, index))
                cout << "Found " << target << " at index " << index << endl;
            else
                cout << "Target not found" << endl;
            break;

        case 3:
            cout << "Press any key to continue" << endl;
            break;

        default:
            cout << "Invalid choice" << endl;
        }
    } while (choice != 3);

    return 0;
}
