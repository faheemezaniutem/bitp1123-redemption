#include "Probability.h"

bool Probability::ProbabilitySearch(int size, int target) {
    for (int i = 0; i < size; i++) {
        if (array[i] == target) {
            locationWanted = i;

            if (i > 0) {
                int temp = array[i - 1];
                array[i - 1] = array[i];
                array[i] = temp;
            }
            return true;
        }
    }
    return false;
}