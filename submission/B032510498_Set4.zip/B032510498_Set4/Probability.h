#ifndef PROBABILITY_H
#define PROBABILITY_H

class Probability {
public:
    int locationWanted;
    int array[10];
    bool ProbabilitySearch(int size, int target);
};

#endif //!PROBABILITY_H