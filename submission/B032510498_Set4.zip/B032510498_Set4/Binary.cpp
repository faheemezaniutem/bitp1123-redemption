#include <iostream>
#include "Binary.h"
using namespace std;

bool Binary::BinarySearch(int size, int target) {
    int begin = 0, end = size - 1, mid;
    while (begin <= end) {
        mid = (begin + end) / 2;
        cout << "mid = " << mid << ", begin = " << begin << ", end = " << end << endl;

        if (target == array[mid]) {
            locationWanted = mid;
            return true;
        }
        else if (target < array[mid])
            end = mid - 1;
        else
            begin = mid + 1;
    }
    return false;
}