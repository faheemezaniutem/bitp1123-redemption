#ifndef BINARY_H
#define BINARY_H

class Binary {
public:
    int locationWanted;
    int array[10];
    bool BinarySearch(int size, int target);
};

#endif // !BINARY_H