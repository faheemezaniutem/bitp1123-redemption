#include <iostream>
#include "Probability.h"
#include "Binary.h"

using namespace std;

const int SIZE = 10;

int main() {
    Probability P;
    Binary B;
    int choice, target;


    int cacheData[] = { 801, 702, 603, 504, 405, 306, 207, 108, 909, 1010 };
    int refData[] = { 100, 200, 300, 400, 500, 600, 700, 800, 900, 1000 };

    for (int i = 0; i < SIZE; i++) {
        P.array[i] = cacheData[i];
        B.array[i] = refData[i];
    }

    cout << "cacheData[] = { 801, 702, 603, 504, 405, 306, 207, 108, 909, 1010 }" << endl;
    cout << "refData[] = { 100, 200, 300, 400, 500, 600, 700, 800, 900, 1000 }" << endl;

    do {
        cout << "\nMenu: 1. Cache (Probability) 2. Reference (Binary) 3. Exit" << endl;
        cout << "Choice: ";
        cin >> choice;

        if (choice == 1) {
            cout << "Insert a target: ";
            cin >> target;
            if (P.ProbabilitySearch(SIZE, target)) {
                cout << "Found " << target << " at index " << P.locationWanted << " (moved up)" << endl;
                cout << "Updated Cache: ";
                for (int i = 0; i < SIZE; i++) cout << P.array[i] << " ";
                cout << endl;
            }
            else {
                cout << "Target not found" << endl;
            }
        }
        else if (choice == 2) {
            cout << "Insert a target: ";
            cin >> target;
            if (B.BinarySearch(SIZE, target))
                cout << "\nFound " << target << " at index " << B.locationWanted << endl;
            else
                cout << "Target not found" << endl;
        }
    } while (choice != 3);

    return 0;
}